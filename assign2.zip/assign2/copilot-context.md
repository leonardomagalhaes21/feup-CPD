# Task: Java Concurrent TCP Chat Server & Client

## Goal
Build a multi-user, room-based chat system in Java (SE 21+) using TCP. Must handle multiple clients concurrently using virtual threads and explicit locking (`java.util.concurrent.locks`), *not* concurrent collections. Includes user authentication, dynamic room creation/joining, and special AI rooms interacting with a local LLM (Ollama). Secure communication (TLS/SSL) is required.

## High-Level Solution Outline
1.  **Server:** Listens for TCP connections. Uses `Executors.newVirtualThreadPerTaskExecutor()` to handle each client on a virtual thread. Manages global state (users, rooms) with explicit locks. Optionally uses SSLServerSocket.
2.  **Client:** Connects to the server via TCP (optionally SSLSocket). Handles user input (commands, messages), sends to server, displays messages received from server. Simple CLI interface.
3.  **Authentication:** Client sends credentials; Server verifies against a simple store (e.g., loaded from file). Authentication must succeed before joining rooms.
4.  **Room Management:**
    *   Global `Map<String, Room>` managed by the Server, protected by a `ReentrantReadWriteLock`.
    *   Each `Room` object contains its name, members (`Set<ClientHandler>`), message history (`List<String>`), and its own `ReentrantReadWriteLock`.
    *   Users can list, join, leave, and create rooms.
5.  **Messaging:** Client sends message; Server finds room, acquires room's write lock, adds message to history, broadcasts to members (acquires room's read lock for member list snapshot, releases lock *before* sending).
6.  **AI Rooms:** Special rooms designated at creation with a prompt. On new user message: add message (under lock), get history+prompt (under lock), release lock, call Ollama HTTP endpoint, get response, add "Bot: response" message (acquiring lock again).
7.  **Concurrency:** Use `Executors.newVirtualThreadPerTaskExecutor()`. Use `ReentrantReadWriteLock` for global room map and for each individual `Room`'s state. Avoid `java.util.concurrent` collections.

## Inputs & Outputs
*   **Inputs:**
    *   Server Port (command line arg)
    *   User Credentials File Path (optional command line arg)
    *   Client Connection (TCP/TLS)
    *   Client Commands: `/login <user> <pass>`, `/list`, `/join <room>`, `/create <room> [prompt]`, `/leave`, message text
    *   Ollama HTTP endpoint (configured in server)
*   **Outputs:**
    *   Server logs (connection/disconnection, errors)
    *   Client prompts for input
    *   Messages broadcast to clients in rooms (e.g., `Alice: Hello!`, `[Bob enters the room]`, `Bot: AI response`)
    *   Server responses to commands (e.g., room list, success/error messages)

## Edge Cases & Constraints
*   **Constraints:** Java SE 21+, Standard Java libraries only (no external libs beyond Java SE), Must use `java.util.concurrent.locks`, Must use Virtual Threads, No `java.util.concurrent` collections, TCP/IP, TLS/SSL required.
*   **Edge Cases:** Abrupt client disconnection, Slow clients (should not block server overall), Authentication failures, Invalid commands, Concurrent join/leave/create actions, Empty rooms, Rooms with same name creation attempt, Ollama unavailable or slow, Network errors, Max message history limit.

## Key Logic Steps
1.  Server init: Load users, setup listener (SSL?), start virtual thread executor.
2.  Client connect: Establish connection (SSL?).
3.  Authentication flow.
4.  Post-auth: Client can list/join/create rooms. Server uses global lock for room map operations.
5.  Room interaction: Client sends message -> Server finds room -> Uses room lock -> Adds history -> Uses room read lock for member list -> Releases lock -> Broadcasts message.
6.  AI Room message: As above, plus async HTTP call to Ollama *outside* room lock, then add Bot message under lock.
7.  Client reads messages from server asynchronously.
8.  Cleanup: Handle disconnects, remove user from room (under lock).
