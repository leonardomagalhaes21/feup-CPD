package chat.server.ai;

public class OllamaService {
}
