package chat.server;

public class Room {
}
